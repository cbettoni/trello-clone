FactoryBot.define do
  factory :board do
    name { "MyString" }
    user { nil }
  end
end
