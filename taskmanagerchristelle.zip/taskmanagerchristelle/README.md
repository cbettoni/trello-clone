# README

Trello clone using Ruby 7, Tailwind and Kanban library tool

# DEPLOYED WEBSITE

https://taskmanagerchristelle.herokuapp.com/

